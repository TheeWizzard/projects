<?php
/** Enable W3 Total Cache */
define('WP_CACHE', true); // Added by W3 Total Cache

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'rpwizar1_landi');

/** MySQL database username */
define('DB_USER', 'rpwizar1_landi');

/** MySQL database password */
define('DB_PASSWORD', 'E(uSp407u!');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'r17tlqjfl52wqoxrlutm5zgqgjpjp3ghpexmbw8bust44vymuxbclh1xx6qfesvm');
define('SECURE_AUTH_KEY',  'szufrvvnybrcxvjgl5r6nxen8eujtau2lopriovqrhjp2coofidgdsr3vrdsmb85');
define('LOGGED_IN_KEY',    'hyxjj0c5dgp8rp44u1q8iw5ivoyei4567qozq3v0ibcvr3ssz5bsvekr0tj9oigw');
define('NONCE_KEY',        'k35zsmjhkcszodwj3m5d44us43cyccmdfowg6flegkr19o8rcgwzcszezvekscan');
define('AUTH_SALT',        '6t8igr4a0uagcxwnknmpzakrwebg9xl4fin88v9koicrirswbalqxabpekz4ied6');
define('SECURE_AUTH_SALT', '5jjkhqinwxx9iab8tls3al0ru1zpkkb3ofmw3wrrhviuvcoq9mluscjnnuu2lhz5');
define('LOGGED_IN_SALT',   'ef2z8wmvjst7nffj1fqsurkobi0cqqxolb3r8j2ic7f9yu9epicrtvrlfg5ovr0c');
define('NONCE_SALT',       'limquyzmou9whug0yqkqhx3axgd9kwlw4ffmecohtsz95n8bckkreaox1z3cjwcw');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wpxv_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
